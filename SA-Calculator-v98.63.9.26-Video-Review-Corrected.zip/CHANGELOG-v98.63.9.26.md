# Changelog — v98.63.9.26

- Rebuilt scientific function matrices to match the supplied screen recording: inverse trig, hyperbolic, inverse hyperbolic, imaginary-unit display key, cube root, 2ˣ, x³, x⁻ʸ, and the circular plus toggle.
- INV now toggles inverse/normal trig and hyperbolic functions one-shot.
- Expanded the Tools catalogue to match the recording's tile order and names, while preserving existing destinations.
- Added Salary (monthly take-home estimate), SIP (monthly contribution projection), and Age (date-of-birth calculator) destinations.
- Added inverse-hyperbolic scalar functions to the expression parser. Complex-number evaluation remains unsupported and is surfaced with a toast.
- Bumped package to `1.98.73-v98.63.9.26`, Android versionCode to `1098074`, and the service-worker cache namespace.
