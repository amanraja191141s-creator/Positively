# Release verification — v98.63.7

Source package identity remains `sa-calculator` / `1.98.63-v98.63` to preserve the existing Android application identity. UI patch release is v98.63.7. The Android workflow uses the exact source manifest and runs `npm test`, `npm run build:web`, Capacitor sync, branding patch and Gradle debug APK build.

This delivery includes source and workflow YAML. It is not an APK and has not been physically installed on a device.
