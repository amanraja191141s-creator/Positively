# Micro-level audit — v98.63.9.22

## Evidence reviewed
- User recording: `Screenrecording_20261121_093938.mp4` (18.88 seconds, 720×1560, 12.66 fps).
- Previous source: `SA-Calculator-v98.63.9.21-Tools-Scientific-Fixed.zip`.
- Previous Android workflow: v98.63.9.21 workflow.

## Defects visible in the supplied recording
1. Other Calculator cards rendered as very tall narrow columns; labels wrapped one character per line (for example, Sales Tax, Loan Calculator, Savings Calculator). This made the cards difficult to scan and visually unlike the intended three-column tile layout.
2. The catalogue appeared to stop at the first Finance & Money group in the captured viewport; the remaining categories needed reliable vertical scrolling.
3. Scientific keypad appeared too narrow for its 4-column function matrix. Multi-character function labels were compressed and the touch targets were too small for comfortable phone use.
4. The recording did not demonstrate reliable access to all four tool groups or all 16 tool destinations.

## Source-level corrections
- Rebuilt the final cascade for the Other Calculator grid with explicit three-column grid tracks and fixed card box-sizing.
- Forced each tool card into a vertical icon-over-label composition; reset inherited grid-area/grid layout metadata on the direct children.
- Prevented per-character wrapping using `word-break:normal`, `overflow-wrap:normal`, `hyphens:none`, and `writing-mode:horizontal-tb`.
- Limited tool labels to two readable lines, retained accessible full `aria-label` values, and kept all 16 destinations in four category groups.
- Made the complete Tools screen vertically scrollable with safe-area bottom padding and momentum scrolling.
- Widened the scientific drawer to 94vw (up to 680px), retained the right-edge overlay behavior, and expanded the 4×4 function buttons to at least 48px high.
- Set the scientific function grid to explicit four-column/four-row tracks, reset button wrapping, and kept the More-functions panel in a responsive four-column layout.
- Bumped app, PWA, service-worker cache, and workflow identities together to `1.98.70-v98.63.9.22` / versionCode `1098070`, so previously cached UI assets are invalidated.

## Preserved behavior
- All 16 existing tool destinations and delegated navigation are retained.
- Unit Converter category-first flow and the existing conversion engine are retained.
- Scientific expression evaluation, DEG/RAD mode, INV one-shot behavior, memory controls, history, cursor editing, equals, and the existing numeric keypad are retained.
- No calculator arithmetic engine was replaced as part of this visual repair.

## Verification
- Release suite: 44/44 passed.
- JavaScript syntax checks: passed.
- Android web bundle generation: passed; 13 required assets verified.
- Workflow YAML parsed successfully.
- ZIP integrity checked after packaging.

## Verification limits
No Android SDK/Gradle APK build, emulator screenshot comparison, or physical-device touch/latency test was executed in this environment. Do not treat those as passed. The full legacy suite still contains 73 historical failures out of 434; the current release gate is the 44-test focused suite.
