const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');

test('v98.27 consolidated reference layer covers all 18 calculator destinations', () => {
  assert.match(css, /v98\.27 — EXACT 18-SCREEN REFERENCE REBUILD/);
  const ids = ['calc','currencies','units','discount','percent','salestax','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','savings','tip','unitprice','worldtime','settings'];
  for (const id of ids) assert.match(html, new RegExp(`id="screen-${id}"`));
  for (const id of ids.slice(1)) assert.match(css, new RegExp(`#screen-${id}`), `missing UI rules for ${id}`);
});

test('reference UI uses the intended navy/blue/green palette and preserves calculation wiring', () => {
  for (const token of ['#071326','#0b1b32','#087fff','#42e58f','#55ed9b']) assert.ok(css.includes(token), `missing palette token ${token}`);
  for (const id of ['tax-calculate','loan-calculate','tip-calculate','unit-price-compare','wt-city-list','date-add-event','btn-add-course']) assert.ok(html.includes(`id="${id}"`), `missing control ${id}`);
  assert.match(js, /function calcLoan\(/);
  assert.match(js, /function calcSalesTax\(/);
  assert.match(js, /function calcTip\(/);
});

test('v98.27 stacked converter fields stay full width and compact layouts remain bounded', () => {
  assert.match(css, /reference-field \.input-val-box[\s\S]*?width:100% !important/);
  assert.match(css, /@media\(max-width:340px\)/);
  assert.match(css, /@media\(max-height:560px\) and \(orientation:landscape\)/);
  assert.match(css, /overscroll-behavior:contain/);
});

test('Date tool adds a UTC-safe date-difference calculator without removing event reminders', () => {
  assert.match(html, /id="date-diff-from"/);
  assert.match(html, /id="date-diff-to"/);
  assert.match(html, /id="date-diff-calculate"/);
  assert.match(html, /id="date-event-list"/);
  assert.match(js, /function dateDifferenceInDays\(/);
  assert.match(js, /Date\.UTC\(year, month - 1, day\)/);
});

test('date difference uses UTC calendar days, handles reverse ranges and rejects invalid dates', () => {
  const vm = require('node:vm');
  const valid = js.match(/function validISODate\([\s\S]*?\n\}/)?.[0];
  const diff = js.match(/function dateDifferenceInDays\([\s\S]*?\n\}/)?.[0];
  assert.ok(valid && diff);
  const context = { Date, Math };
  vm.runInNewContext(`${valid};${diff};globalThis.diff=dateDifferenceInDays;`, context);
  assert.equal(context.diff('2025-01-01','2025-12-31'),364);
  assert.equal(context.diff('2025-12-31','2025-01-01'),-364);
  assert.equal(context.diff('2024-02-28','2024-03-01'),2);
  assert.equal(context.diff('2025-02-29','2025-03-01'),null);
});


test('Android workflow verifies the same exact v98.27 cache identity as the source', () => {
  const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
  assert.match(workflow, /sa-calculator-v98-63-10-clean-runtime-v9863917/);
  assert.match(workflow, /SA_EXPECTED_VERSION: '1\.98\.65-v98\.63\.9\.17'/);
  assert.match(workflow, /versionCode='1098065'/);
});
