import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('assets/css/app.css','utf8');
test('expanded scientific panel is constrained to function area and uses high contrast dark surface',()=>{
 const correction=css.slice(css.lastIndexOf('v98.63.9.26 review correction'));
 assert.match(correction,/scientific-more-functions:not\(\[hidden\]\)[\s\S]*inset:clamp\(132px,24dvh,190px\) 8px clamp\(196px,31dvh,260px\)/);
 assert.match(correction,/background:#081a2b/); assert.match(correction,/color:#dceeff/);
 assert.doesNotMatch(correction,/background:#e9518d/);
});
test('scientific extra-functions overlay leaves base expression display and keypad intact',()=>{
 const correction=css.slice(css.lastIndexOf('v98.63.9.26 review correction'));
 assert.match(correction,/scientific-more-functions:not\(\[hidden\]\)[\s\S]*position:absolute/);
 assert.match(correction,/scientific-function-grid > button[\s\S]*background:#102941/);
});
test('tools catalogue has reserved bottom-nav scroll area and touch scrolling',()=>{
 const correction=css.slice(css.lastIndexOf('v98.63.9.26 review correction'));
 assert.match(correction,/#screen-tools\.premium-tools-screen\.active[\s\S]*overflow-y:auto/);
 assert.match(correction,/padding-bottom:calc\(118px\s*\+\s*env\(safe-area-inset-bottom,0px\)\)/);
 assert.match(correction,/tools-reference-groups[\s\S]*padding-bottom:calc\(132px\s*\+\s*env\(safe-area-inset-bottom,0px\)\)/);
 assert.match(html,/id="premium-tools-grid"/);
});
test('unit picker keeps list scrolling separate from header and search',()=>{
 const correction=css.slice(css.lastIndexOf('v98.63.9.26 review correction'));
 assert.match(correction,/sumaire-picker-options[\s\S]*flex:1 1 0!important[\s\S]*overflow-y:auto/);
 assert.match(correction,/sumaire-picker-header[\s\S]*flex-shrink:0/);
});
