const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

test('Currency Converter is vertically stacked and recalculates automatically without a manual Convert action', () => {
  const html = read('index.html'); const css = read('assets/css/app.css'); const js = read('assets/js/app.js');
  assert.doesNotMatch(html, /id="currency-convert-action"/);
  assert.match(html, /id="cur-amount"[^>]*><span class="input-text">100<\/span>/);
  assert.match(js, /return \{ from: 'USD', to: 'EUR' \}/);
  assert.match(css, /#screen-currencies \.currency-input-row \{\s*display:\s*flex\s*!important;\s*flex-direction:\s*column\s*!important/);
  assert.match(css, /#screen-currencies #cur-to-amount \{ background:linear-gradient/);
  assert.doesNotMatch(js, /getElementById\('currency-convert-action'\)/);
  assert.match(js, /fromSel\.addEventListener\('change',[\s\S]*?calcCurrency\(\)/);
  assert.match(js, /toSel\.addEventListener\('change',[\s\S]*?calcCurrency\(\)/);
  assert.match(js, /case 'currencies': calcCurrency\(\); break;/);
});

test('Unit Converter matches stacked category/from/value/to/result flow and has a wired action', () => {
  const html = read('index.html'); const css = read('assets/css/app.css'); const js = read('assets/js/app.js');
  assert.match(html, /id="unit-convert-action"/);
  assert.match(html, /<option value="length" selected>Length<\/option>/);
  assert.match(html, /id="unit-input-val"[\s\S]*?<span class="input-text">1<\/span>/);
  assert.match(js, /catSel\.value = 'length'/);
  assert.match(js, /if \(cat === 'length'\) \{ f\.value = 'Meter \(m\)'/);
  assert.match(html, /id="discount-calculate"/);
  assert.match(html, /id="percent-mode-select"/);
  assert.match(html, /id="percent-calculate"/);
  assert.match(js, /getElementById\('discount-calculate'\)\?\.addEventListener\('click', calcDiscount\)/);
  assert.match(js, /getElementById\('percent-calculate'\)\?\.addEventListener\('click', calcPercent\)/);
  assert.match(css, /#screen-units \.calc-card \.input-row \{ display:\s*flex\s*!important;\s*flex-direction:\s*column\s*!important/);
  assert.match(css, /#screen-units \.unit-result-value \{ width:100% !important/);
  assert.match(js, /getElementById\('unit-convert-action'\)\?\.addEventListener\('click'/);
  assert.match(js, /calcUnits\(\);\s*const result = document\.getElementById\('unit-result-val'\)/);
});

test('v98.27 release identity and workflows are synchronized', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const sw = read('service-worker.js'); const html = read('index.html');
  const workflow = read('.github/workflows/main.yml');
  assert.equal(pkg.version, '1.98.65-v98.63.9.17');
  assert.equal(manifest.version, pkg.version);
  assert.ok(html.includes(pkg.version));
  assert.ok(read('assets/js/app.js').includes(`const APP_VERSION = '${pkg.version}'`));
  assert.match(sw, /sa-calculator-v98-63-10-clean-runtime-v9863917/);
  assert.match(workflow, /SA_EXPECTED_VERSION: '1\.98\.65-v98\.63\.9\.17'/);
  assert.match(workflow, /versionCode='1098065'/);
  assert.equal(workflow, read('.github/workflows/main.yml'));
});
